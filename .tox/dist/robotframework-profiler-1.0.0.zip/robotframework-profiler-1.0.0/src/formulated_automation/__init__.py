"""Our namespace init along with VERSION"""

from .version import VERSION